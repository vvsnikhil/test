
class RedisError(Exception):
    pass
